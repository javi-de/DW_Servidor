<html>
	<head>
		<title>Problema</title>
	</head>
	<body bgcolor="<?php echo $_COOKIE['micolor'];  ?>">
	    Se creó la cookie.
	    <br>
	    <a href="pagina3.php">Ir a la otra página</a>
	</body>
</html>
